C/Migemo Library.

README
  See doc/README_j.txt (Japanese).

LICENSE
  See doc/LICENSE_MIT.txt (English) or doc/LICENSE_j.txt (Japanese).

TODO
  See doc/TODO_j.txt (Japanese).

For Vim Plugin Use
  If you want to use this repository only as a vim plugin, use https://github.com/haya14busa/vim-migemo
